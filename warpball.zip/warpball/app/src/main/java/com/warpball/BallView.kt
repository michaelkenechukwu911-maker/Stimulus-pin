package com.warpball

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import kotlin.math.min

/** The floating ball. Colour shows the mode: pink = editing pins, teal = pass-through, grey = layer hidden. */
class BallView(context: Context) : View(context) {

    enum class Mode { EDIT, PASS, HIDDEN }

    var mode = Mode.EDIT
        set(value) { field = value; invalidate() }

    private val d = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.WHITE; strokeWidth = 3 * d
    }
    private val glyph = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; strokeWidth = 3 * d; strokeCap = Paint.Cap.ROUND
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(cx, cy) - 4 * d
        fill.color = when (mode) {
            Mode.EDIT -> 0xFFF2528D.toInt()
            Mode.PASS -> 0xFF2BB3A3.toInt()
            Mode.HIDDEN -> 0xFF6B7488.toInt()
        }
        canvas.drawCircle(cx, cy, r, fill)
        canvas.drawCircle(cx, cy, r, ring)
        canvas.drawCircle(cx, cy - 5 * d, 6 * d, glyph)
        canvas.drawLine(cx, cy + 1 * d, cx, cy + 11 * d, glyph)
    }
}
