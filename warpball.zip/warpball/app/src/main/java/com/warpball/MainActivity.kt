package com.warpball

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min

/** Setup screen: overlay permission, start live capture or image mode, stop. */
class MainActivity : ComponentActivity() {

    private lateinit var status: TextView
    private var pendingLive = false

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) saveLayer(uri)
    }
    private val askNotifications = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        proceed(pendingLive) // the overlay works even if the notification is hidden
    }
    private val capture = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == RESULT_OK && data != null) {
            startOverlay(r.resultCode, data)
        } else {
            Toast.makeText(this, "Screen capture was not allowed", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        status = TextView(this).apply { textSize = 16f; setPadding(0, 0, 0, pad) }
        col.addView(status)

        fun button(label: String, onClick: () -> Unit) {
            val b = Button(this@MainActivity)
            b.text = label
            b.isAllCaps = false
            b.setOnClickListener { onClick() }
            col.addView(b)
        }

        button("1. Allow display over other apps") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        button("2. Start live: freeze the screen, then warp it") { startFlow(true) }
        button("Image mode: choose an image") { pickImage.launch("image/*") }
        button("Image mode: start") { startFlow(false) }
        button("Stop the floating tool") { stopService(Intent(this@MainActivity, OverlayService::class.java)) }

        col.addView(TextView(this).apply {
            textSize = 13f
            setPadding(0, pad, 0, 0)
            text = "Live mode: go to any app, tap the grey ball to freeze the screen, then drop pins and drag.\n" +
                "Tap the ball again to hide the layer and return to the live app.\n" +
                "Hold the ball: pass touches through (teal). Drag the ball to move it.\n" +
                "When Android asks what to share, choose the entire screen."
        })
        setContentView(col)
    }

    override fun onResume() {
        super.onResume()
        status.text = if (Settings.canDrawOverlays(this))
            "Display over other apps: allowed"
        else
            "Display over other apps: not allowed yet"
    }

    private fun startFlow(live: Boolean) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow display over other apps first", Toast.LENGTH_SHORT).show()
            return
        }
        pendingLive = live
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            proceed(live)
        }
    }

    private fun proceed(live: Boolean) {
        if (live) {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            capture.launch(mpm.createScreenCaptureIntent())
        } else {
            startOverlay(0, null)
        }
    }

    private fun startOverlay(code: Int, data: Intent?) {
        if (!Settings.canDrawOverlays(this)) return
        val i = Intent(this, OverlayService::class.java)
        if (data != null) {
            i.putExtra(OverlayService.EXTRA_CODE, code)
            i.putExtra(OverlayService.EXTRA_DATA, data)
        }
        startForegroundService(i)
        moveTaskToBack(true)
    }

    /** Image mode: downscales the picked image to 1024px max and stores it where the overlay can read it. */
    private fun saveLayer(uri: Uri) {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > 2048) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: throw IllegalStateException("decode failed")
            val s = min(1f, 1024f / max(bmp.width, bmp.height))
            val out = if (s < 1f)
                Bitmap.createScaledBitmap(bmp, (bmp.width * s).toInt(), (bmp.height * s).toInt(), true)
            else bmp
            FileOutputStream(File(filesDir, "layer.png")).use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            if (OverlayService.running) {
                startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_RELOAD))
            }
            Toast.makeText(this, "Layer image saved", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not use that image", Toast.LENGTH_SHORT).show()
        }
    }
}
