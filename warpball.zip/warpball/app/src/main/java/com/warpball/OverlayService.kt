package com.warpball

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.util.Base64
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Toast
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.math.hypot
import kotlin.math.max

/**
 * Foreground service that owns two overlay windows:
 *  - a full-screen transparent WebView running the puppet warp tool
 *  - the draggable ball that controls it
 *
 * Live mode: a MediaProjection virtual display keeps the newest screen frame. Tapping the grey
 * ball hides the ball, grabs that frame, hands it to the page, and the page shows it as a frozen
 * copy of the screen that can be warped. (Capturing continuously would feed the overlay back
 * into itself, so it works on a frozen snapshot.)
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_EXIT = "com.warpball.EXIT"
        const val ACTION_RELOAD = "com.warpball.RELOAD"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "warpball"
        @Volatile var running = false
    }

    private lateinit var wm: WindowManager
    private lateinit var layerLp: LP
    private lateinit var ballLp: LP
    private var web: WebView? = null
    private var ball: BallView? = null
    private var live = false
    private var layerVisible = true
    private var passThrough = false
    private val handler = Handler(Looper.getMainLooper())
    private val baseFlags = LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS

    // live capture state
    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var reader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var latest: Image? = null
    private var frames = 0
    private var snapshotBusy = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_EXIT -> { stopSelf(); return START_NOT_STICKY }
            ACTION_RELOAD -> { web?.reload(); return START_NOT_STICKY }
        }
        if (ball == null) {
            live = intent?.hasExtra(EXTRA_DATA) == true
            goForeground()
            if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
            if (live && !startCapture(intent!!)) { stopSelf(); return START_NOT_STICKY }
            layerVisible = !live // live mode starts hidden: go to an app, then tap the ball
            addWindows()
            running = true
        }
        return START_NOT_STICKY
    }

    /* ---------- foreground notification ---------- */

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Floating warp tool", NotificationManager.IMPORTANCE_LOW)
        )
        val exit = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_EXIT), PendingIntent.FLAG_IMMUTABLE
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val note = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_pin)
            .setContentTitle(if (live) "Puppet warp is ready" else "Puppet warp is floating")
            .setContentText(
                if (live) "Tap the ball to freeze the screen and warp it."
                else "Tap the ball to show or hide. Hold it to pass touches through."
            )
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Exit", exit
                ).build()
            )
            .build()
        val type = when {
            live -> ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            Build.VERSION.SDK_INT >= 34 -> ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            else -> 0
        }
        if (Build.VERSION.SDK_INT >= 29 && type != 0) startForeground(1, note, type) else startForeground(1, note)
    }

    /* ---------- screen capture ---------- */

    @Suppress("DEPRECATION")
    private fun dataFrom(i: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else i.getParcelableExtra<Intent>(EXTRA_DATA)

    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            return b.width() to b.height()
        }
        val m = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        return m.widthPixels to m.heightPixels
    }

    private fun startCapture(i: Intent): Boolean {
        val data = dataFrom(i) ?: return false
        return try {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            val p = mpm.getMediaProjection(i.getIntExtra(EXTRA_CODE, 0), data)
            // Android 14+ requires a callback before creating the virtual display.
            val cb = object : MediaProjection.Callback() {
                override fun onStop() { handler.post { stopSelf() } }
            }
            p.registerCallback(cb, handler)
            projection = p
            projectionCallback = cb

            val (w, h) = screenSize()
            val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
            // keep only the newest frame open, so a static screen still has a frame to grab
            r.setOnImageAvailableListener({ rd ->
                val img = try { rd.acquireLatestImage() } catch (e: Exception) { null }
                if (img != null) { latest?.close(); latest = img; frames++ }
            }, handler)
            reader = r
            // Android 14+ allows one virtual display per projection, so it is created once and kept.
            virtualDisplay = p.createVirtualDisplay(
                "warpball", w, h, resources.displayMetrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler
            )
            true
        } catch (e: Exception) {
            Toast.makeText(this, "Could not start screen capture", Toast.LENGTH_LONG).show()
            false
        }
    }

    private fun snapshotThenShow() {
        val b = ball ?: return
        if (snapshotBusy) return
        snapshotBusy = true
        b.visibility = View.INVISIBLE // keep the ball out of the picture
        val startFrames = frames
        val t0 = SystemClock.uptimeMillis()
        val poll = object : Runnable {
            override fun run() {
                val waited = SystemClock.uptimeMillis() - t0
                if ((frames > startFrames && waited > 100) || waited > 500) finishSnapshot()
                else handler.postDelayed(this, 30)
            }
        }
        handler.postDelayed(poll, 60)
    }

    private fun finishSnapshot() {
        ball?.visibility = View.VISIBLE
        val img = latest
        if (img == null) {
            snapshotBusy = false
            Toast.makeText(this, "No screen frame yet. Try again.", Toast.LENGTH_SHORT).show()
            return
        }
        val url = toDataUrl(toBitmap(img))
        // the page calls Bridge.snapshotReady() once the picture is loaded, then the layer appears
        web?.evaluateJavascript("window.setSnapshot('$url')", null)
    }

    private fun toBitmap(img: Image): Bitmap {
        val plane = img.planes[0]
        val pixelStride = plane.pixelStride
        val rowPadding = plane.rowStride - pixelStride * img.width
        val padded = Bitmap.createBitmap(img.width + rowPadding / pixelStride, img.height, Bitmap.Config.ARGB_8888)
        val buf = plane.buffer
        buf.rewind()
        padded.copyPixelsFromBuffer(buf)
        return if (rowPadding == 0) padded else Bitmap.createBitmap(padded, 0, 0, img.width, img.height)
    }

    private fun toDataUrl(src: Bitmap): String {
        val longSide = max(src.width, src.height)
        val s = if (longSide > 1920) 1920f / longSide else 1f
        val bmp = if (s < 1f)
            Bitmap.createScaledBitmap(src, (src.width * s).toInt(), (src.height * s).toInt(), true)
        else src
        val bos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 90, bos)
        return "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
    }

    /* ---------- windows ---------- */

    private fun addWindows() {
        val dm = resources.displayMetrics

        layerLp = LP(LP.MATCH_PARENT, LP.MATCH_PARENT, LP.TYPE_APPLICATION_OVERLAY, baseFlags, PixelFormat.TRANSLUCENT)
            .apply {
                gravity = Gravity.TOP or Gravity.START
                if (Build.VERSION.SDK_INT >= 28) {
                    layoutInDisplayCutoutMode = LP.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
                if (Build.VERSION.SDK_INT >= 30) fitInsetsTypes = 0 // snapshot must line up with the real screen
            }
        val w = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.javaScriptEnabled = true
            addJavascriptInterface(Bridge(applicationContext) {
                handler.post {
                    snapshotBusy = false
                    layerVisible = true
                    passThrough = false
                    applyState()
                }
            }, "Android")
            loadUrl("file:///android_asset/puppet-warp.html")
        }
        web = w
        wm.addView(w, layerLp)

        val size = (56 * dm.density).toInt()
        ballLp = LP(
            size, size, LP.TYPE_APPLICATION_OVERLAY,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dm.widthPixels - size - (12 * dm.density).toInt()
            y = (dm.heightPixels * 0.4f).toInt()
        }
        val b = BallView(this)
        ball = b
        attachBallTouch(b)
        wm.addView(b, ballLp) // added last, so it sits above the layer
        applyState()
    }

    private fun applyState() {
        val v = web ?: return
        v.visibility = if (layerVisible) View.VISIBLE else View.GONE
        var f = baseFlags
        if (!layerVisible || passThrough) f = f or LP.FLAG_NOT_TOUCHABLE
        layerLp.flags = f
        // Android 12+ only delivers touches to the app underneath an overlay when its alpha is 0.8 or less.
        layerLp.alpha = if (passThrough) 0.8f else 1f
        wm.updateViewLayout(v, layerLp)
        ball?.mode = when {
            !layerVisible -> BallView.Mode.HIDDEN
            passThrough -> BallView.Mode.PASS
            else -> BallView.Mode.EDIT
        }
    }

    private fun onBallTap() {
        if (live && !layerVisible) snapshotThenShow() else { layerVisible = !layerVisible; applyState() }
    }

    private fun onBallHold() {
        if (live && !layerVisible) return // nothing to pass through yet
        passThrough = !passThrough
        layerVisible = true
        applyState()
    }

    private fun attachBallTouch(v: BallView) {
        var startX = 0f; var startY = 0f
        var originX = 0; var originY = 0
        var dragging = false; var longFired = false
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        val longPress = Runnable {
            longFired = true
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            onBallHold()
        }
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = e.rawX; startY = e.rawY
                    originX = ballLp.x; originY = ballLp.y
                    dragging = false; longFired = false
                    handler.postDelayed(longPress, 450)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - startX
                    val dy = e.rawY - startY
                    if (!dragging && hypot(dx, dy) > slop) {
                        dragging = true
                        handler.removeCallbacks(longPress)
                    }
                    if (dragging) {
                        ballLp.x = (originX + dx).toInt()
                        ballLp.y = (originY + dy).toInt()
                        wm.updateViewLayout(v, ballLp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longPress)
                    if (!dragging && !longFired) onBallTap()
                }
                MotionEvent.ACTION_CANCEL -> handler.removeCallbacks(longPress)
            }
            true
        }
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        try { web?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { ball?.let { wm.removeView(it) } } catch (_: Exception) {}
        web?.destroy()
        web = null; ball = null
        latest?.close(); latest = null
        virtualDisplay?.release(); virtualDisplay = null
        reader?.close(); reader = null
        projectionCallback?.let { projection?.unregisterCallback(it) }
        projection?.stop(); projection = null
        super.onDestroy()
    }
}

/** Exposed to the page as `window.Android`. */
class Bridge(private val ctx: Context, private val onSnapshotReady: () -> Unit) {
    /** Image mode: the image picked in MainActivity as a data URL, or "" to keep the built-in sample. */
    @JavascriptInterface
    fun getLayerDataUrl(): String {
        val f = File(ctx.filesDir, "layer.png")
        if (!f.exists()) return ""
        return "data:image/png;base64," + Base64.encodeToString(f.readBytes(), Base64.NO_WRAP)
    }

    /** Live mode: the page finished loading the frozen screen picture. */
    @JavascriptInterface
    fun snapshotReady() { onSnapshotReady() }
}
