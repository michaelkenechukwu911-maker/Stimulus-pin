# Warp Ball

<img src="branding/logo.png" width="96" alt="Warp Ball logo">

Puppet warp tool that floats over other apps, controlled by a draggable ball.

## Build
1. Open this folder in Android Studio (Koala or newer). Let Gradle sync.
   If it asks about the Gradle wrapper, accept the suggested Gradle 8.7.
2. Run on a physical device (Android 8+).

## Get the APK from GitHub
1. Push this folder to a GitHub repository (branch `main`). The workflow in `.github/workflows/build-apk.yml` runs by itself.
2. Open the repository's **Actions** tab, then the latest **Build APK** run. When it turns green, the APK is under **Artifacts** as `warpball-apk`.
3. For a permanent download link, push a tag such as `v0.1`. The APK is attached to a **Release**.
4. On the phone, open the downloaded zip or APK and allow "install unknown apps" for your browser or file manager.

It builds a debug APK, signed with the standard debug key. That installs fine for testing; a Play Store build needs your own signing key.

## Live mode (screen capture)
1. Tap "Allow display over other apps" and switch Warp Ball on.
2. Tap "Start live". When Android asks what to share, choose the entire screen.
3. Go to your drawing. Drag the ball onto it and let go. The screen freezes and a pin drops where the ball was.
4. Drag more pins in the same way, then drag the pins on the screen to warp. Double-tap a pin to remove it.
5. Tap the ball to hide the layer and get the live app back. Dragging the ball in again takes a fresh snapshot.

## Image mode
Choose an image, then start. The image is the warp layer. Same ball controls, no screen capture.

## Ball
- Drag onto the screen and let go: drops a pin there (freezes the screen first in live mode). The ball springs back.
- Drag to a screen edge and let go: moves the ball's resting spot to that edge.
- Tap: show or hide the layer (in live mode a tap while grey takes a snapshot).
- Hold: pass touches through to the app below (teal). Hold again to edit pins (pink).
- Exit from the notification.

## Files
- `OverlayService.kt`: foreground service, overlay windows, screen capture, snapshot hand-off.
- `BallView.kt`: the ball.
- `MainActivity.kt`: permission flow, capture consent, image picker, start and stop.
- `assets/puppet-warp.html`: the warp tool (web prototype plus overlay rules and `window.setSnapshot`).

## Notes
- Live mode warps a frozen snapshot, not live video. Capturing continuously would record the overlay itself.
  Taps under a snapshot do not reach the real app; hide the layer first.
- Portrait only for now. Rotating the phone leaves the capture at the old size.
- Android 14+ lets people share a single app instead of the whole screen; pick the entire screen.
- Android 12+ only passes touches through an overlay whose alpha is 0.8 or less, so pass-through dims the layer to 80%.
- Xiaomi/HyperOS: if the ball vanishes in the background, enable "Display pop-up windows while running in the background" and Autostart for Warp Ball.
- Launcher and notification icons are placeholder system icons.
